package food.DTO;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrandAUth {
	private Long brandId;
	private Long fileId;
	private String name;
	private String location;
	private String phone;
	private String auth;
	private Timestamp createAt;
	private Timestamp updatedAt;
}