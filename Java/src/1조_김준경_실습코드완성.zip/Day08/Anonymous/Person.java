package Day08.Anonymous;

public class Person {
	String name;
	int age;
	
	void work() {
		System.out.println("일을 합니다.");
	}
}
