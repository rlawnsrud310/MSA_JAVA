package Day08.Ex02_Multillmplement;

public interface Microphone {
	
		int inputVoLumeMax = 50;
		int inputVoLumeMin = 00;
		
		String receiveVoice(String voice);
}
