package D10_13.Ex03_WildCard;

public class HighStudent extends Student{

	public HighStudent(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "HighStudent ["+this.getName()+"]";
	}

}
