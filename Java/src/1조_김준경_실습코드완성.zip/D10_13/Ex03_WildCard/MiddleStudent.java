package D10_13.Ex03_WildCard;

public class MiddleStudent extends Student{

	public MiddleStudent(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "MiddleStudent ["+this.getName()+"]";
	}

}
