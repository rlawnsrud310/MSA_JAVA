package Day02;

public class Ex11_ArithmeticOperator {

	public static void main(String[] args) {
		// 산술 연산자
		System.out.println(10 + 20);
		System.out.println(8 - 5);
		System.out.println(5 * 4);
		System.out.println(23/4);
		
		System.out.println(8 % 6);
		
		System.out.println(1 % 5);
		System.out.println(2 % 5);
		System.out.println(3 % 5);
		System.out.println(4 % 5);
		System.out.println(5 % 5);
		System.out.println();
		
		System.out.println(6 % 5);
		System.out.println(7 % 5);
		System.out.println(8 % 5);
		System.out.println(9 % 5);
		System.out.println(10 % 5);
		System.out.println();
	}
}
