package Day01;

public class Ex02_Print {
	
	// main : ctrl + space
	public static void main(String[] args) {
		// 기본 출력문
		// - print(), println() 메소드를 호출하여 출력한다.
		// - System.out 객체를 사용한다.
		// print();
		System.out.print("안녕하세요");
		
		// println();
		// : 지정한 문자열을 출력 후, 한 줄 엔터
		System.out.println("안녕하세요 출력 후 줄바꿈");
		
		System.out.println("자바 첫 수업");
		System.out.println();
		// 문자열 : "" 큰따옴표로 묶어있는 데이터
	}

}

